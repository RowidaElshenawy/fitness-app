import axiosInstance from '@/lib/axios';

import type {
  ActivityLevel,
  Gender,
  Goal,
} from '@/features/KYC/types/kyc';

interface ISignupRequest {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  rePassword: string;
  gender: Gender;
  height: number;
  weight: number;
  age: number;
  goal: Goal;
  activityLevel: ActivityLevel;
}

export const signup = async (payload: ISignupRequest) => {
  await axiosInstance.post('/auth/signup', payload);
};